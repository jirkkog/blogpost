const express = require('express');
const app = express();
const port = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

const blogPosts = [
    {
        id: 1,
        title: 'First Blog Post',
        content: 'Hi, my name is Rustem, im from BDA-2207 group and I welcome you to my blogpost!',
        date: '2023-11-01',
    },
];

app.get('/', (req, res) => {
    res.render('home', { blogPosts });
});

app.get('/add', (req, res) => {
    res.render('add-post');
});

app.get('/post/:id', (req, res) => {
    const postId = parseInt(req.params.id);
    const post = blogPosts.find(post => post.id === postId);
    
    if (post) {
        res.render('post-details', { post });
    } else {
        res.status(404).send('Post not found');
    }
});

app.post('/add-post', (req, res) => {
    const { title, content } = req.body;
    const newPost = {
        id: blogPosts.length + 1,
        title,
        content,
        date: new Date().toLocaleDateString(),
    };
    blogPosts.push(newPost);
    res.redirect('/');
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});